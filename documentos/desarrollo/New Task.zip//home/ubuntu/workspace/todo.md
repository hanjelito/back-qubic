# Lista de Tareas para el Proyecto de Hackaton

## Análisis y Planificación
- [x] Analizar el documento de la hackaton
- [x] Crear la estructura del MVP
- [x] Diseñar los endpoints de la API
- [x] Generar ejemplos de JSON para los endpoints
- [x] Desarrollar la presentación en texto
- [x] Validar la solución completa
- [x] Preparar los entregables finales

## Detalles del Proyecto
- Plataforma blockchain para financiación colectiva de jugadores de fútbol
- Permite a los fanáticos contribuir económicamente comprando tokens
- Cumple con el Challenge 1: "Financing System Using Tokenized RWAs"
